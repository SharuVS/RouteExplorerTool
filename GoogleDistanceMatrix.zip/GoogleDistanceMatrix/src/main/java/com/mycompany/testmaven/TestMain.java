package com.mycompany.testmaven;

import com.google.maps.model.LatLng;
import com.google.maps.DirectionsApi;
import com.google.maps.GeoApiContext;
import com.google.maps.model.DirectionsResult;
import com.google.maps.model.DirectionsRoute;
import com.google.maps.model.TravelMode;
import com.mapbox.services.commons.ServicesException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestMain 
{
    HashMap<Integer , Job> Jobs = new HashMap<>();
    public static void main(String args[]) throws IOException, FileNotFoundException, ServicesException, Exception
    {
        System.out.println("Inside main()");
        TestMain tm = new TestMain();
        tm.getData();
        System.out.println("Done");
    }
    public void getData() throws FileNotFoundException, IOException, ServicesException, Exception
    {
        System.out.println("Inside getData()");
        int i;
        for(i=0;i<=88;i++)
        {
            String file1 = "Daywise.xlsx";
            File myfile = new File(file1);
            FileInputStream fis = new FileInputStream(myfile);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet mySheet = wb.getSheetAt(i);
            Iterator<Row> rowIterator = mySheet.iterator();
            int j=0;
            while (rowIterator.hasNext()) 
            {
                j++;
                Row row = rowIterator.next();
                Cell cell0 = row.getCell(0);
                int c1 = (int)cell0.getNumericCellValue();  //Key
                Cell cell1 = row.getCell(1);
                double c2 = cell1.getNumericCellValue();    //Time
                Cell cell2 = row.getCell(2);
                double c3 = cell2.getNumericCellValue();    //Lat
                Cell cell3 = row.getCell(3);
                double c4 = cell3.getNumericCellValue();    //Lng
                Cell cell4 = row.getCell(4);
                String c5 = cell4.getStringCellValue();     //Driver
                Job j1 = new Job(c1,c5,c2,c3,c4);
                Jobs.put(j, j1);
            }
            GoogleCalc(i+1);
            Jobs.clear();
        }
    }
    public void GoogleCalc(int sheetIndex) throws FileNotFoundException, IOException, Exception 
    {
        System.out.println("Inside GoogleCalc()");
        String GoogleApiKey = "AIzaSyDjNE_d4J_UasGamExwLYjqJk8EIIgwpVM";
        ArrayList<LatLng> waypts = new ArrayList<>();
        for(int i=1;i<=Jobs.size();i++)
        {
           LatLng pos = new LatLng(Jobs.get(i).lat , Jobs.get(i).lng);
           waypts.add(pos);
        }
        String file1 = "GoogleDuration.xlsx";
        String file2 = "GoogleDistance.xlsx";
        File myfile1 = new File(file1);
        File myfile2 = new File(file2);
        FileInputStream fis1 = new FileInputStream(myfile1);
        FileInputStream fis2 = new FileInputStream(myfile2);
        XSSFWorkbook wb1 = new XSSFWorkbook(fis1);
        XSSFWorkbook wb2 = new XSSFWorkbook(fis2);
        String sheetname = "Sheet"+sheetIndex;
        System.out.println(sheetname);
        XSSFSheet mySheet1;
        XSSFSheet mySheet2;
        if("Sheet1".equalsIgnoreCase(sheetname))
        {
            mySheet1 = wb1.getSheet(sheetname);
            mySheet2 = wb2.getSheet(sheetname);
        }
        else
        {
            mySheet1 = wb1.createSheet(sheetname);
            mySheet2 = wb2.createSheet(sheetname);
        }
        for(int i=1;i<=waypts.size();i++)
        {
            int rownum1 = mySheet1.getLastRowNum(); 
            int rownum2 = mySheet2.getLastRowNum();
            rownum1++;
            rownum2++;
            Row row1 = mySheet1.createRow(rownum1);
            Row row2 = mySheet2.createRow(rownum2);
            
            for(int j=1;j<=waypts.size();j++)
            {
                if(j==i)
                {
                    double calc_time = Double.POSITIVE_INFINITY;
                    double calc_dist = Double.POSITIVE_INFINITY;
                    Cell cell1 = row1.createCell(j); 
                    cell1.setCellValue((Double) calc_time); 
                    FileOutputStream os1 = new FileOutputStream(myfile1);
                    wb1.write(os1); 
                    Cell cell2 = row2.createCell(j); 
                    cell2.setCellValue((Double) calc_dist); 
                    FileOutputStream os2 = new FileOutputStream(myfile2);
                    wb1.write(os2); 
                }
                else
                {
                    GeoApiContext context = new GeoApiContext().setApiKey(GoogleApiKey);
                    DirectionsResult r = DirectionsApi.newRequest(context).origin(waypts.get(i)).destination(waypts.get(j)).mode(TravelMode.DRIVING).await();
                    DirectionsRoute[] route = r.routes;     
                    double calc_time = route[0].legs[0].duration.inSeconds;
                    Cell cell1 = row1.createCell(j); 
                    cell1.setCellValue((Double) calc_time); 
                    FileOutputStream os1 = new FileOutputStream(myfile1);
                    wb1.write(os1); 
                    double calc_dist = (route[0].legs[0].distance.inMeters)/1000;
                    Cell cell2 = row2.createCell(j); 
                    cell2.setCellValue((Double) calc_dist); 
                    FileOutputStream os2 = new FileOutputStream(myfile2);
                    wb2.write(os2); 
                } 
            }
        }
    }
    class Job
    {
        private int key;
        private double lat;
        private double time;
        private String driver;
        private double lng;
        public Job(int key, String driver, double time, double lat, double lng)
        {
            this.key=key;
            this.driver = driver;
            this.time = time;
            this.lat = lat;
            this.lng = lng;
        }
        public String getDriver() 
        {
            return driver;
        }
        public double getTime() 
        {
            return time;
        }
        public double getLat() 
        {
            return lat;
        }
        public double getLng() 
        {
            return lng;
        }
        public int getKey() 
        {
            return key;
        }
        @Override
        public String toString() 
        {
            return "Job [Key=" +key +", Driver=" + driver + ", time=" + time + ", Lat=" + lat + ", Lng=" + lng + "]";
        }
    }
}