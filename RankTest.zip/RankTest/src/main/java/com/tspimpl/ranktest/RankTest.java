package com.tspimpl.ranktest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class RankTest 
{
    String trainingFile = "Ranks.xlsx";
    String testingFile = "RanksOutput.xlsx";
    double GM,GH,MB;
    int count=0;
    int result[] = new int[3];
    public static void main(String[] args) throws IOException 
    {
        RankTest rt = new RankTest();
        rt.getdata();
        System.out.println("Successfully done..!!");
    }
    public void getdata() throws FileNotFoundException, IOException
    {
        File myFile = new File(trainingFile); 
        FileInputStream fis = new FileInputStream(myFile); // Finds the workbook instance for XLSX file 
        XSSFWorkbook myWorkBook = new XSSFWorkbook (fis); // Return first sheet from the XLSX workbook 
        XSSFSheet mySheet = myWorkBook.getSheetAt(0); // Get iterator to all the rows in current sheet 
        Iterator<Row> rowIterator = mySheet.iterator(); // Traversing over each row of XLSX file 
        while (rowIterator.hasNext()) 
        {
            Row row = rowIterator.next(); // For each row, iterate through each columns 
            Cell cell0 = row.getCell(0);
            Cell cell1 = row.getCell(1);
            Cell cell2 = row.getCell(2);
            MB = (double) cell0.getNumericCellValue();
            GM = (double) cell1.getNumericCellValue();
            GH = (double)cell2.getNumericCellValue();
            //System.out.println("MB : "+MB+" GM : "+GM+" GH : "+GH);
            System.out.println(count);
            /*if(count == 2)
            {
                System.exit(0);
            }*/
            if(MB < GM && MB < GH)
            {
                result[0] = 1;
                if(GM < GH)
                {
                    result[1] = 2;
                    result[2] = 3;
                }
                else
                {
                    result[1] = 3;
                    result[2] = 2;
                }
            }
            if(GM < MB && GM < GH)
            {
                result[1]= 1;
                if(MB < GH)
                {
                    result[0]=2;
                    result[2]=3;
                }
                else
                {
                    result[0]=3;
                    result[2]=2;
                }
            }
            if(GH < MB && GH < GM)
            {
                result[2]= 1;
                if(GM < MB)
                {
                    result[0]=3;
                    result[1]=2;
                }
                else
                {
                    result[1]=3;
                    result[0]=2;
                }
            }
            writeTofile(count);
            count++;
        }
    }
    public void writeTofile(int rown) throws FileNotFoundException, IOException
    {
        File myFile = new File(testingFile); 
        FileInputStream fis = new FileInputStream(myFile); // Finds the workbook instance for XLSX file 
        XSSFWorkbook myWorkBook = new XSSFWorkbook (fis);
        XSSFSheet mySheet = myWorkBook.getSheetAt(0);
        Row row = mySheet.createRow(rown);
        Cell cell1 = row.createCell(0); 
        cell1.setCellValue((int) result[0]);
        Cell cell2 = row.createCell(1);
        cell2.setCellValue((int) result[1]);
        Cell cell3 = row.createCell(2);
        cell3.setCellValue((int) result[2]);
        FileOutputStream os = new FileOutputStream(myFile);
        myWorkBook.write(os); 
        System.out.println("Writing on XLSX file Finished ..."); 
    }
}
