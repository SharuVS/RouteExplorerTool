package com.mapbox.mapboxrestructured;
import com.mapbox.services.commons.ServicesException;
import com.mapbox.services.commons.models.Position;
import com.mapbox.services.directions.v5.DirectionsCriteria;
import com.mapbox.services.directions.v5.MapboxDirections;
import com.mapbox.services.directions.v5.models.DirectionsResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import retrofit2.Response;

public class MapTest 
{
    HashMap<Integer , Job> Jobs = new HashMap<>();
    ArrayList<Position> waypts = new ArrayList<>();
    Position orgin ;
    String MapBoxKey = "pk.eyJ1Ijoic2hhcnV2cyIsImEiOiJjaXFsNmR6Z3cwMDJyaXJtMnR2YmtybHl0In0.kaQcTOdc2nGLV7zLs_jXzg";
    public static void main(String[] args) throws ServicesException, Exception 
    {
        MapTest mt = new MapTest();
        mt.getData();
        System.out.println("Done");
    } 
    public void getData() throws FileNotFoundException, IOException, ServicesException, Exception
    {
        int m;
        Jobs = new HashMap<>();
        System.out.println("Inside getData()");
        for(int i=1;i<=50;i++)
        {
            String file1 = "Daywise.xlsx";
            File myfile = new File(file1);
            FileInputStream fis = new FileInputStream(myfile);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            String s = "Sheet"+i;
            XSSFSheet mySheet = wb.getSheet(s);
            Iterator<Row> rowIterator = mySheet.iterator();
            int j=0;
            while (rowIterator.hasNext()) 
            {
                j++;
                Row row = rowIterator.next();
                Cell cell0 = row.getCell(0);
                int c1 = (int)cell0.getNumericCellValue();  //Key
                Cell cell1 = row.getCell(1);
                double c2 = cell1.getNumericCellValue();    //Time
                Cell cell2 = row.getCell(2);
                double c3 = cell2.getNumericCellValue();    //Lat
                Cell cell3 = row.getCell(3);
                double c4 = cell3.getNumericCellValue();    //Lng
                Cell cell4 = row.getCell(4);
                String c5 = cell4.getStringCellValue();     //Driver
                Job j1 = new Job(c1,c5,c2,c3,c4);
                Jobs.put(j, j1);
            }
            int size = Jobs.size();
            
            if(size <= 25)
            {
                System.out.println("Inside <=25 loop");
                double d1 = 0,d2 = 0;
                m=1;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.exit(0);
                }
                Position pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 2;k<=Jobs.size();k++)
                {
                    d1 = Jobs.get(k).lat;
                    d2 = Jobs.get(k).lng;
                    
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double calc[] = MapBoxCalc();
                writetoFile(calc[0], calc[1]);
                System.out.println("Finished MapBoxCalc <=25");
            }
            if(size > 25 && size <=50)
            {
                System.out.println("Inside <=50 loop");
                double d1 = 0,d2 = 0;
                m=1;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.out.println("Hello");
                    System.exit(0);
                }
                Position pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 2;k<=25;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.out.println("say say");
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double []calc1 = MapBoxCalc();
                waypts.clear();
                m=26;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.out.println("Hi HI");
                    System.exit(0);
                    
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k=27;k<=Jobs.size();k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.out.println("Bye  Bye");
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double []calc2 = MapBoxCalc();
                double a = calc1[0]+calc2[0];
                double b = calc1[1]+calc2[1];
                writetoFile(a, b);
                System.out.println("Finished writing MapBoxCalc =<50");
            }
            if(size > 50 && size <=75)
            {
                System.out.println("Inside <=75 loop");
                double d1 = 0,d2 = 0;
                m=1;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                   
                }
                else
                {
                    System.exit(0);
                }
                Position pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 2;k<=25;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                
                double [] calc1 = MapBoxCalc();
                waypts.clear();
                m=26;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.exit(0);
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k=27;k<=50;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double [] calc2 = MapBoxCalc();
                waypts.clear();
                m=51;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                   
                }
                else
                {
                        System.out.println("say say");
                        System.exit(0);
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 52;k<=Jobs.size();k++)
                {   
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double calc3[] = MapBoxCalc();
                double a = calc1[0]+calc2[0]+calc3[0];
                double b = calc1[1]+calc2[1]+calc3[1];
                writetoFile(a,b); 
                System.out.println("Finished < 75");
            }
            if(size > 75 && size <=100)
            {
                System.out.println("Inside <=125 loop");
                double d1 = 0,d2 = 0;
                m=1;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                   
                }
                else
                {
                    System.exit(0);
                }
                Position pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 2;k<=25;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double calc1[] = MapBoxCalc();
                waypts.clear();
                m=26;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                   
                }
                else
                {
                    System.exit(0);
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k=27;k<=50;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                       
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double calc2[] = MapBoxCalc();
                waypts.clear();
                m=51;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.exit(0);
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 52;k<=75;k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double []calc3 = MapBoxCalc();
                waypts.clear();
                m = 76;
                if(Jobs.containsKey(m))
                {
                    d1 = Jobs.get(m).lat;
                    d2 = Jobs.get(m).lng;
                    
                }
                else
                {
                    System.exit(0);
                }
                pos = Position.fromCoordinates(d2, d1);
                orgin = pos;
                for(int k = 77;k<=Jobs.size();k++)
                {
                    if(Jobs.containsKey(k))
                    {
                        d1 = Jobs.get(k).lat;
                        d2 = Jobs.get(k).lng;
                        
                    }
                    else
                    {
                        System.exit(0);
                    }
                    pos = Position.fromCoordinates(d2, d1);
                    waypts.add(pos);
                }
                double []calc4 = MapBoxCalc();
                double a = calc1[0]+calc2[0]+calc3[0]+calc4[0];
                double b = calc1[1]+calc2[1]+calc3[1]+calc4[1];
                writetoFile(a,b);
                System.out.println("Finished < 125");
            }
            Jobs.clear();
        }
    }
    public double[] MapBoxCalc() throws IOException, ServicesException
    {
        System.out.println("Inside MapBoxCalc()");
        double[] calc;
        calc= new double[]{0,0};
        MapboxDirections client2 = new MapboxDirections.Builder().setAccessToken(MapBoxKey).setOrigin(orgin).setCoordinates(waypts).setDestination(orgin).setSteps(Boolean.TRUE).setProfile(DirectionsCriteria.PROFILE_DRIVING).build();
        Response<DirectionsResponse> res = client2.executeCall();
        if(res.isSuccessful())
        {
            double time = res.body().getRoutes().get(0).getDuration();
            double calc_time = time/60;
            double distance = res.body().getRoutes().get(0).getDistance();
            double calc_dist = distance/1000; 
            calc[0] = calc_dist;
            calc[1] = calc_time;
        }
        return calc;
    }
    public void writetoFile(double calc_dist , double calc_time) throws FileNotFoundException, IOException
    {
        String file1 = "MapboxCalc.xlsx";
        File myfile1 = new File(file1);
        FileInputStream fis1 = new FileInputStream(myfile1);
        XSSFWorkbook wb1 = new XSSFWorkbook(fis1);
        String sheetname = "Sheet1";
        XSSFSheet mySheet1;
        mySheet1 = wb1.getSheet(sheetname);
        int rownum1 = mySheet1.getLastRowNum();
        rownum1++;
        Row row1 = mySheet1.createRow(rownum1);
        Cell cell1 = row1.createCell(0);
        Cell cell2 = row1.createCell(1); 
        cell1.setCellValue(calc_time);
        cell2.setCellValue(calc_dist);
        FileOutputStream os1 = new FileOutputStream(myfile1);
        wb1.write(os1); 
    }
    
    class Job
    {
        int key;
        double lat;
        double time;
        String driver;
        double lng;
        public Job(int key, String driver, double time, double lat, double lng)
        {
            this.key=key;
            this.driver = driver;
            this.time = time;
            this.lat = lat;
            this.lng = lng;
        }
        public String getDriver() 
        {
            return driver;
        }
        public double getTime() 
        {
            return time;
        }
        public double getLat() 
        {
            return lat;
        }
        public double getLng() 
        {
            return lng;
        }
        public int getKey() 
        {
            return key;
        }
        @Override
        public String toString() 
        {
            return "Job [Key=" +key +", Driver=" + driver + ", time=" + time + ", Lat=" + lat + ", Lng=" + lng + "]";
        }
    }
}
    

